
export enum MessageAuthor {
  USER = 'user',
  AI = 'ai',
}

export interface ChatMessage {
  author: MessageAuthor;
  text: string;
}

export interface Persona {
  id: string;
  name: string;
  description: string;
  systemInstruction: string;
  placeholder: string;
}

export enum VoiceState {
  IDLE = 'idle',
  CONNECTING = 'connecting',
  LISTENING = 'listening',
  SPEAKING = 'speaking', // Note: Not used yet, but good for future implementation
  ERROR = 'error',
}


import React, { useState, useCallback, useRef, useEffect } from 'react';
// Fix: Removed non-existent type 'LiveSession'.
import type { Chat, LiveServerMessage } from '@google/genai';
import { Modality } from '@google/genai';
import { ChatInterface } from './components/ChatInterface';
import { PersonaSelector } from './components/PersonaSelector';
import { LogoIcon } from './components/Icons';
import { startChat, connectLiveSession } from './services/geminiService';
import { createBlob, decode, decodeAudioData, playFeedbackTone } from './utils';
import type { ChatMessage, Persona } from './types';
import { MessageAuthor, VoiceState } from './types';
import { PERSONAS } from './constants';

const App: React.FC = () => {
    const [selectedPersona, setSelectedPersona] = useState<Persona>(PERSONAS[0]);
    const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [hasStarted, setHasStarted] = useState<boolean>(false);
    
    // Voice chat state
    const [isVoiceSessionActive, setIsVoiceSessionActive] = useState<boolean>(false);
    const [voiceState, setVoiceState] = useState<VoiceState>(VoiceState.IDLE);
    const [userTranscript, setUserTranscript] = useState('');
    const [aiTranscript, setAiTranscript] = useState('');

    const chatRef = useRef<Chat | null>(null);
    // Fix: 'LiveSession' is not an exported type. Using 'any' for the session object.
    const sessionRef = useRef<any | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const microphoneStreamRef = useRef<MediaStream | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const nextStartTimeRef = useRef<number>(0);
    const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

    useEffect(() => {
        // Reset chat when persona changes
        stopVoiceSession();
        setHasStarted(false);
        setChatHistory([]);
        chatRef.current = null;
    }, [selectedPersona]);

    const stopVoiceSession = useCallback(async () => {
        if (!isVoiceSessionActive && !sessionRef.current) return;

        // Play end tone only if we were actually active
        if (isVoiceSessionActive) {
            playFeedbackTone('end');
        }

        setIsVoiceSessionActive(false);
        setVoiceState(VoiceState.IDLE);
        
        sessionRef.current?.close();
        sessionRef.current = null;
        
        microphoneStreamRef.current?.getTracks().forEach(track => track.stop());
        microphoneStreamRef.current = null;
        
        scriptProcessorRef.current?.disconnect();
        scriptProcessorRef.current = null;

        await inputAudioContextRef.current?.close();
        inputAudioContextRef.current = null;

        // Stop any playing audio
        audioSourcesRef.current.forEach(source => source.stop());
        audioSourcesRef.current.clear();
        nextStartTimeRef.current = 0;
        await outputAudioContextRef.current?.close();
        outputAudioContextRef.current = null;

        setUserTranscript('');
        setAiTranscript('');

    }, [isVoiceSessionActive]);


    const handleToggleVoiceSession = useCallback(async () => {
        if (isVoiceSessionActive) {
            await stopVoiceSession();
            return;
        }

        setError(null);
        setVoiceState(VoiceState.CONNECTING);

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            microphoneStreamRef.current = stream;

            // Fix: Cast 'window' to 'any' to allow access to 'webkitAudioContext' for broader browser compatibility.
            inputAudioContextRef.current = new ((window as any).AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new ((window as any).AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            let currentInputTranscription = '';
            let currentOutputTranscription = '';

            const sessionPromise = connectLiveSession({
                systemInstruction: selectedPersona.systemInstruction,
                callbacks: {
                    onopen: () => {
                        setVoiceState(VoiceState.LISTENING);
                        setHasStarted(true);
                        playFeedbackTone('start');

                        const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                        scriptProcessorRef.current = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                        
                        scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromise.then((session) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };
                        
                        source.connect(scriptProcessorRef.current);
                        scriptProcessorRef.current.connect(inputAudioContextRef.current!.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        if (message.serverContent?.inputTranscription) {
                            currentInputTranscription += message.serverContent.inputTranscription.text;
                            setUserTranscript(currentInputTranscription);
                        }
                        if (message.serverContent?.outputTranscription) {
                             currentOutputTranscription += message.serverContent.outputTranscription.text;
                             setAiTranscript(currentOutputTranscription);
                        }
                        
                        if (message.serverContent?.turnComplete) {
                            const finalUserMessage: ChatMessage = { author: MessageAuthor.USER, text: currentInputTranscription };
                            const finalAiMessage: ChatMessage = { author: MessageAuthor.AI, text: currentOutputTranscription };
                            setChatHistory(prev => [...prev, finalUserMessage, finalAiMessage]);
                            currentInputTranscription = '';
                            currentOutputTranscription = '';
                            setUserTranscript('');
                            setAiTranscript('');
                        }

                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64Audio) {
                            // When audio is received, we are effectively 'speaking'
                            setVoiceState(VoiceState.SPEAKING);

                            const outputCtx = outputAudioContextRef.current!;
                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                            
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                            const source = outputCtx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputCtx.destination);
                            
                            source.addEventListener('ended', () => {
                                audioSourcesRef.current.delete(source);
                                // If no more audio sources are playing, revert to listening
                                if (audioSourcesRef.current.size === 0) {
                                    setVoiceState(VoiceState.LISTENING);
                                }
                            });
                            
                            source.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            audioSourcesRef.current.add(source);
                        }

                        if (message.serverContent?.interrupted) {
                            audioSourcesRef.current.forEach(source => source.stop());
                            audioSourcesRef.current.clear();
                            nextStartTimeRef.current = 0;
                            setVoiceState(VoiceState.LISTENING);
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error(e);
                        setError(`Voice session error: ${e.message}`);
                        setVoiceState(VoiceState.ERROR);
                        playFeedbackTone('error');
                        stopVoiceSession();
                    },
                    onclose: () => {
                        stopVoiceSession();
                    },
                }
            });
            
            sessionRef.current = await sessionPromise;
            setIsVoiceSessionActive(true);

        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to start voice session. Please check microphone permissions. Error: ${errorMessage}`);
            setVoiceState(VoiceState.ERROR);
            playFeedbackTone('error');
            await stopVoiceSession();
        }

    }, [isVoiceSessionActive, selectedPersona.systemInstruction, stopVoiceSession]);


    const handleSendMessage = useCallback(async (message: string) => {
        setIsLoading(true);
        setError(null);
        
        const userMessage: ChatMessage = { author: MessageAuthor.USER, text: message };
        setChatHistory(prev => [...prev, userMessage]);

        try {
            if (!chatRef.current) {
                chatRef.current = startChat(selectedPersona.systemInstruction);
                setHasStarted(true);
            }

            const stream = await chatRef.current.sendMessageStream({ message });
            
            let aiResponse = '';
            const aiMessage: ChatMessage = { author: MessageAuthor.AI, text: '' };
            setChatHistory(prev => [...prev, aiMessage]);

            for await (const chunk of stream) {
                aiResponse += chunk.text;
                setChatHistory(prev => {
                    const newHistory = [...prev];
                    const lastMessage = newHistory[newHistory.length - 1];
                    if (lastMessage.author === MessageAuthor.AI) {
                        lastMessage.text = aiResponse;
                    }
                    return newHistory;
                });
            }

        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to get response from AI. Error: ${errorMessage}`);
            setChatHistory(prev => prev.slice(0, -2)); // Remove user and empty AI message
        } finally {
            setIsLoading(false);
        }
    }, [selectedPersona]);

    return (
        <div className="flex flex-col h-screen bg-base-dark-100 text-base-dark-content font-sans antialiased">
            <header className="flex items-center justify-between p-4 border-b border-base-dark-300 shadow-md bg-base-dark-200 z-10">
                <div className="flex items-center space-x-3">
                    <LogoIcon className="h-8 w-8 text-brand-primary" />
                    <h1 className="text-xl font-bold text-white tracking-tight">
                        Socratic AI Debate Mentor
                    </h1>
                </div>
                <div className="w-64">
                    <PersonaSelector
                        personas={PERSONAS}
                        selectedPersona={selectedPersona}
                        onSelectPersona={setSelectedPersona}
                        disabled={isLoading || hasStarted}
                    />
                </div>
            </header>

            <main className="flex-1 overflow-y-auto">
                <ChatInterface
                    chatHistory={chatHistory}
                    isLoading={isLoading}
                    onSendMessage={handleSendMessage}
                    persona={selectedPersona}
                    hasStarted={hasStarted}
                    isVoiceSessionActive={isVoiceSessionActive}
                    voiceState={voiceState}
                    userTranscript={userTranscript}
                    aiTranscript={aiTranscript}
                    onToggleVoiceSession={handleToggleVoiceSession}
                />
            </main>

            {error && (
                <div className="absolute bottom-4 right-4 bg-red-500 text-white p-4 rounded-lg shadow-xl max-w-sm z-50">
                    <h3 className="font-bold">Error</h3>
                    <p>{error}</p>
                    <button onClick={() => setError(null)} className="absolute top-1 right-2 text-xl font-bold">&times;</button>
                </div>
            )}
        </div>
    );
};

export default App;

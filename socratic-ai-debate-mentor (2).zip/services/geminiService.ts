
// Fix: Removed non-exported types 'LiveSession' and 'LiveSessionCallbacks' and added 'LiveServerMessage' for use in callbacks.
import { GoogleGenAI, Chat, Modality, LiveServerMessage } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const startChat = (systemInstruction: string): Chat => {
    const chat: Chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: systemInstruction,
            temperature: 0.7,
            topP: 0.9,
            topK: 40,
        },
    });
    return chat;
};

// Fix: 'LiveSessionCallbacks' is not an exported type. Defined a local interface for it.
interface LiveSessionCallbacks {
    onopen: () => void;
    onmessage: (message: LiveServerMessage) => void;
    onerror: (e: ErrorEvent) => void;
    onclose: (e: CloseEvent) => void;
}

interface ConnectLiveSessionParams {
    systemInstruction: string;
    callbacks: LiveSessionCallbacks;
}

// Fix: 'LiveSession' is not an exported type. The function will return a Promise of 'any'.
export const connectLiveSession = ({ systemInstruction, callbacks }: ConnectLiveSessionParams): Promise<any> => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks,
        config: {
            systemInstruction: systemInstruction,
            responseModalities: [Modality.AUDIO],
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
        },
    });
};

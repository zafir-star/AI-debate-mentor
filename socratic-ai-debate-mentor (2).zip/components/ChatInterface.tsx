
import React, { useState, useRef, useEffect } from 'react';
import type { ChatMessage, Persona } from '../types';
import { MessageAuthor, VoiceState } from '../types';
import { UserIcon, MentorIcon, SendIcon, ThinkingIcon, MicrophoneIcon, MicrophoneSlashIcon } from './Icons';

interface ChatInterfaceProps {
    chatHistory: ChatMessage[];
    isLoading: boolean;
    onSendMessage: (message: string) => void;
    persona: Persona;
    hasStarted: boolean;
    isVoiceSessionActive: boolean;
    voiceState: VoiceState;
    userTranscript: string;
    aiTranscript: string;
    onToggleVoiceSession: () => void;
}

const ChatBubble: React.FC<{ message: ChatMessage }> = ({ message }) => {
    const isUser = message.author === MessageAuthor.USER;
    return (
        <div className={`flex items-start gap-4 ${isUser ? 'justify-end' : ''}`}>
            {!isUser && <div className="flex-shrink-0 h-10 w-10 rounded-full bg-base-dark-300 flex items-center justify-center text-brand-light"><MentorIcon /></div>}
            <div className={`max-w-xl lg:max-w-3xl px-5 py-3 rounded-2xl shadow-md ${isUser ? 'bg-brand-primary text-white rounded-br-none' : 'bg-base-dark-200 text-base-dark-content rounded-bl-none'}`}>
                <p className="whitespace-pre-wrap">{message.text}</p>
            </div>
            {isUser && <div className="flex-shrink-0 h-10 w-10 rounded-full bg-base-dark-300 flex items-center justify-center"><UserIcon /></div>}
        </div>
    );
};

const WelcomeScreen: React.FC<{ persona: Persona }> = ({ persona }) => (
    <div className="flex flex-col items-center justify-center h-full text-center p-8">
        <div className="w-24 h-24 rounded-full bg-base-dark-200 flex items-center justify-center mb-6 border-4 border-base-dark-300">
            <MentorIcon className="w-12 h-12 text-brand-primary" />
        </div>
        <h2 className="text-3xl font-bold text-white mb-2">Debate with {persona.name}</h2>
        <p className="text-lg text-base-dark-content max-w-2xl">{persona.description}</p>
        <p className="mt-8 text-sm text-gray-400">Enter your initial text below or use the microphone to begin.</p>
    </div>
);

const LiveTranscript: React.FC<{ user: string, ai: string, voiceState: VoiceState }> = ({ user, ai, voiceState }) => (
    <div className="px-6 pb-2 text-sm text-gray-400 transition-all duration-300 ease-in-out">
         {/* Show status if no text yet */}
        {!user && !ai && voiceState === VoiceState.LISTENING && <p className="text-red-400 animate-pulse font-medium">Listening...</p>}
        {!user && !ai && voiceState === VoiceState.SPEAKING && <p className="text-green-400 animate-pulse font-medium">Mentor Speaking...</p>}
        
        {user && <p><span className="font-bold text-gray-300">You:</span> {user}</p>}
        {ai && <p><span className="font-bold text-brand-light">Mentor:</span> {ai}</p>}
    </div>
);


export const ChatInterface: React.FC<ChatInterfaceProps> = ({
    chatHistory,
    isLoading,
    onSendMessage,
    persona,
    hasStarted,
    isVoiceSessionActive,
    voiceState,
    userTranscript,
    aiTranscript,
    onToggleVoiceSession,
}) => {
    const [message, setMessage] = useState('');
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        chatContainerRef.current?.scrollTo({
            top: chatContainerRef.current.scrollHeight,
            behavior: 'smooth'
        });
    }, [chatHistory, userTranscript, aiTranscript]);
    
    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
        }
    }, [message]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (message.trim() && !isLoading && !isVoiceSessionActive) {
            onSendMessage(message);
            setMessage('');
        }
    };
    
    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit(e as unknown as React.FormEvent);
        }
    };

    const isInputDisabled = isLoading || isVoiceSessionActive;

    const getMicVisuals = () => {
        switch (voiceState) {
            case VoiceState.CONNECTING:
                return {
                    button: 'bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30 ring-1 ring-yellow-500/50',
                    icon: 'animate-spin opacity-75',
                    label: 'Connecting'
                };
            case VoiceState.LISTENING:
                return {
                    button: 'bg-red-500/20 text-red-500 hover:bg-red-500/30 ring-2 ring-red-500 animate-pulse',
                    icon: '',
                    label: 'Listening'
                };
            case VoiceState.SPEAKING:
                return {
                    button: 'bg-green-500/20 text-green-500 hover:bg-green-500/30 ring-2 ring-green-500 shadow-[0_0_15px_rgba(34,197,94,0.5)]',
                    icon: 'animate-bounce', // Simple animation to denote activity
                    label: 'Speaking'
                };
            case VoiceState.ERROR:
                return {
                    button: 'bg-red-900/50 text-red-500 ring-1 ring-red-500',
                    icon: '',
                    label: 'Error'
                };
            default: // IDLE
                return {
                    button: 'text-gray-400 hover:text-white hover:bg-base-dark-300',
                    icon: '',
                    label: ''
                };
        }
    };

    const visuals = getMicVisuals();

    return (
        <div className="flex flex-col h-full">
            <div ref={chatContainerRef} className="flex-1 p-6 space-y-6 overflow-y-auto">
                {!hasStarted && <WelcomeScreen persona={persona} />}
                {chatHistory.map((msg, index) => (
                    <ChatBubble key={index} message={msg} />
                ))}
                {isLoading && !isVoiceSessionActive && (
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-base-dark-300 flex items-center justify-center text-brand-light"><MentorIcon /></div>
                        <div className="max-w-xl lg:max-w-3xl px-5 py-3 rounded-2xl shadow-md bg-base-dark-200 text-base-dark-content rounded-bl-none">
                            <ThinkingIcon />
                        </div>
                    </div>
                )}
            </div>
            <div className="border-t border-base-dark-300 bg-base-dark-100 sticky bottom-0">
                {(isVoiceSessionActive || userTranscript || aiTranscript) && (
                    <LiveTranscript user={userTranscript} ai={aiTranscript} voiceState={voiceState} />
                )}
                <div className="p-4 pt-2">
                    <form onSubmit={handleSubmit} className="max-w-4xl mx-auto bg-base-dark-200 rounded-xl p-2 flex items-end border border-base-dark-300 focus-within:border-brand-primary transition-colors">
                        <textarea
                            ref={textareaRef}
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder={hasStarted ? 'Respond to the mentor...' : persona.placeholder}
                            className="flex-1 bg-transparent p-2 text-base-dark-content placeholder-gray-500 resize-none focus:outline-none max-h-48"
                            rows={1}
                            disabled={isInputDisabled}
                        />
                        
                         <div className="relative group">
                            {visuals.label && isVoiceSessionActive && (
                                <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-base-dark-300 text-xs text-white px-2 py-1 rounded shadow-lg whitespace-nowrap">
                                    {visuals.label}
                                </div>
                            )}
                            <button
                                type="button"
                                onClick={onToggleVoiceSession}
                                disabled={isLoading}
                                className={`p-2 rounded-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-brand-light ${visuals.button} mr-2`}
                                aria-label={isVoiceSessionActive ? "Stop voice session" : "Start voice session"}
                            >
                                <div className={visuals.icon}>
                                    {isVoiceSessionActive ? <MicrophoneSlashIcon /> : <MicrophoneIcon />}
                                </div>
                            </button>
                         </div>

                        <button type="submit" disabled={isInputDisabled || !message.trim()} className="p-2 rounded-lg text-white bg-brand-primary disabled:bg-base-dark-300 disabled:text-gray-500 hover:bg-brand-dark transition-colors focus:outline-none focus:ring-2 focus:ring-brand-light">
                            <SendIcon />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

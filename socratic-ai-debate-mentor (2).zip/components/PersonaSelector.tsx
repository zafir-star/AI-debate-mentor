import React from 'react';
import type { Persona } from '../types';

interface PersonaSelectorProps {
    personas: Persona[];
    selectedPersona: Persona;
    onSelectPersona: (persona: Persona) => void;
    disabled: boolean;
}

export const PersonaSelector: React.FC<PersonaSelectorProps> = ({ personas, selectedPersona, onSelectPersona, disabled }) => {
    const handleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const persona = personas.find(p => p.id === event.target.value);
        if (persona) {
            onSelectPersona(persona);
        }
    };

    return (
        <div className="relative">
            <select
                value={selectedPersona.id}
                onChange={handleChange}
                disabled={disabled}
                className="w-full appearance-none bg-base-dark-300 border border-base-dark-300 text-white font-semibold py-2 px-4 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-base-dark-300 focus:border-brand-primary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
                {personas.map(persona => (
                    <option key={persona.id} value={persona.id}>
                        {persona.name}
                    </option>
                ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                </svg>
            </div>
        </div>
    );
};
